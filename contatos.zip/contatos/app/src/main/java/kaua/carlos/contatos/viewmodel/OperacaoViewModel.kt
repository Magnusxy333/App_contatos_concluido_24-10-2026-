package kaua.carlos.contatos.viewmodel

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import java.io.IOException
import kotlinx.coroutines.*

open class OperacaoViewModel : ViewModel() {
    var ocupado by mutableStateOf(false)
        private set
    var mensagem by mutableStateOf<String?>(null)
        protected set
    private var trabalho: Job? = null

    protected fun executar(acao: suspend () -> Unit) {
        if (ocupado) return
        ocupado = true
        mensagem = null
        trabalho = viewModelScope.launch {
            try {
                acao()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                mensagem = "Falha de conexão. Confira a API e a rede."
            } catch (e: Exception) {
                mensagem = e.message ?: "Não foi possível concluir"
            } finally {
                ocupado = false
            }
        }
    }

    fun limparMensagem() { mensagem = null }

    fun cancelar() {
        trabalho?.cancel()
        ocupado = false
        mensagem = null
    }
}